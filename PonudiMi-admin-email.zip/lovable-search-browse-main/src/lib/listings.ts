import { supabase } from "@/integrations/supabase/client";

export type Ponuda = {
  id: string;
  naslov: string;
  opis: string | null;
  kategorija: string;
  lokacija: string;
  cena: number | null;
  valuta: string;
  emoji: string | null;
  istaknuto: boolean;
  zavrseno?: boolean;
  updated_at?: string | null;
  kontakt_ime?: string | null;
  telefon?: string | null;
  created_at: string;
};

export type Zahtev = {
  id: string;
  naslov: string;
  opis: string | null;
  kategorija: string;
  lokacija: string;
  budzet: number | null;
  zavrseno?: boolean;
  updated_at?: string | null;
  kontakt_ime?: string | null;
  telefon?: string | null;
  valuta: string;
  created_at: string;
};

export function formatCena(value: number | null, valuta = "EUR") {
  if (value === null || value === undefined) return "Po dogovoru";
  const simbol = valuta === "EUR" ? "€" : valuta;
  return `${new Intl.NumberFormat("sr-Latn-RS").format(value)} ${simbol}`;
}

export function formatVreme(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const sati = Math.floor(diff / 3_600_000);
  if (sati < 1) return "upravo sada";
  if (sati < 24) return `pre ${sati} ${sati === 1 ? "sat" : sati < 5 ? "sata" : "sati"}`;
  const dana = Math.floor(sati / 24);
  return `pre ${dana} ${dana === 1 ? "dan" : "dana"}`;
}

export const ponudeQuery = (limit?: number, samoIstaknute = false) => ({
  queryKey: ["ponude", limit ?? "sve", samoIstaknute],
  queryFn: async (): Promise<Ponuda[]> => {
    const rezultat: Ponuda[] = [];
    const velicinaStrane = limit ?? 1000;

    for (let od = 0; ; od += velicinaStrane) {
      let upit = supabase
        .from("ponude")
        .select("*")
        .order("created_at", { ascending: false })
        .order("id", { ascending: false });
      if (samoIstaknute) upit = upit.eq("istaknuto", true);
      if (limit) upit = upit.limit(limit);

      const { data, error } = await upit.range(od, od + velicinaStrane - 1);
      if (error) throw error;
      const strana = (data ?? []) as Ponuda[];
      rezultat.push(...strana);

      if (limit || strana.length < velicinaStrane) break;
    }

    return rezultat;
  },
});

export const zahteviQuery = (limit?: number) => ({
  queryKey: ["zahtevi", limit ?? "sve"],
  queryFn: async (): Promise<Zahtev[]> => {
    const rezultat: Zahtev[] = [];
    const velicinaStrane = limit ?? 1000;

    for (let od = 0; ; od += velicinaStrane) {
      let upit = supabase
        .from("zahtevi")
        .select("*")
        .order("created_at", { ascending: false })
        .order("id", { ascending: false });
      if (limit) upit = upit.limit(limit);

      const { data, error } = await upit.range(od, od + velicinaStrane - 1);
      if (error) throw error;
      const strana = (data ?? []) as Zahtev[];
      rezultat.push(...strana);

      if (limit || strana.length < velicinaStrane) break;
    }

    return rezultat;
  },
});

export type SearchResults = { ponude: Ponuda[]; zahtevi: Zahtev[] };

export const pretragaQuery = (q: string, lokacija: string) => ({
  queryKey: ["pretraga", q, lokacija],
  queryFn: async (): Promise<SearchResults> => {
    const args = { q: q.slice(0, 200), mesto: lokacija.slice(0, 100) };

    async function ucitajSve<T extends { id: string }>(
      tabela: "ponude" | "zahtevi",
    ): Promise<T[]> {
      const rezultat: T[] = [];
      const velicinaStrane = 1000;

      for (let od = 0; ; od += velicinaStrane) {
        const odgovor =
          tabela === "ponude"
            ? await supabase
                .rpc("pretrazi_ponude", args)
                .order("created_at", { ascending: false })
                .order("id", { ascending: false })
                .range(od, od + velicinaStrane - 1)
            : await supabase
                .rpc("pretrazi_zahteve", args)
                .order("created_at", { ascending: false })
                .order("id", { ascending: false })
                .range(od, od + velicinaStrane - 1);

        if (odgovor.error) throw odgovor.error;
        const strana = (odgovor.data ?? []) as T[];
        rezultat.push(...strana);
        if (strana.length < velicinaStrane) break;
      }

      return rezultat;
    }

    const [ponude, zahtevi] = await Promise.all([
      ucitajSve<Ponuda>("ponude"),
      ucitajSve<Zahtev>("zahtevi"),
    ]);

    return { ponude, zahtevi };
  },
});

export type Izmena = { id: string; oglas_id: string; opis: string; created_at: string };

export const izmeneQuery = (oglasId: string) => ({
  queryKey: ["izmene", oglasId],
  queryFn: async (): Promise<Izmena[]> => {
    const { data, error } = await supabase.from("izmene_oglasa").select("id, oglas_id, opis, created_at").eq("oglas_id", oglasId).order("created_at", { ascending: false }).limit(10);
    if (error) throw error;
    return data ?? [];
  },
});
